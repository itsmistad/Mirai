#!/bin/bash

node ../src/migrations/migrator.js $1