/* eslint no-unused-vars: 0 */
'use strict';

module.exports = new function() {
    this.desc = 'Creates nothing; this is just a template for migration scripts.';

    this.up = async function(m) {
        
    };

    this.down = async function(m) {
        
    };
};